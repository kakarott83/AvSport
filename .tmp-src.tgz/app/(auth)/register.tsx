import { router } from "expo-router";
import { useState } from "react";
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

import { LanguageSwitch } from "@/components/LanguageSwitch";
import { SocialAuthButtons } from "@/components/SocialAuthButtons";
import { getAuthErrorMessage } from "@/lib/authErrors";
import { useTranslation } from "@/lib/i18n";
import { supabase } from "@/services/supabaseClient";

export default function RegisterScreen() {
  const { t } = useTranslation();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [socialBusy, setSocialBusy] = useState(false);

  async function handleRegister() {
    if (!email.trim() || !password) {
      Alert.alert(t("auth.requiredFields"), t("auth.enterEmailPassword"));
      return;
    }
    if (password !== confirmPassword) {
      Alert.alert(
        t("auth.passwordMismatchTitle"),
        t("auth.passwordMismatch"),
      );
      return;
    }
    if (password.length < 6) {
      Alert.alert(t("auth.passwordTooShortTitle"), t("auth.passwordTooShort"));
      return;
    }

    setLoading(true);

    try {
      const { data, error } = await supabase.auth.signUp({
        email: email.trim(),
        password,
      });

      if (error) {
        Alert.alert(
          t("auth.registerFailed"),
          getAuthErrorMessage(error.message),
        );
        return;
      }

      if (data.session) {
        // Session sofort aktiv (kein E-Mail-Bestätigung) → _layout.tsx übernimmt Routing
      } else {
        Alert.alert(
          t("auth.confirmEmailTitle"),
          t("auth.confirmEmail"),
          [{ text: t("common.ok"), onPress: () => router.replace("/(auth)/login") }],
        );
      }
    } catch (error) {
      Alert.alert(
        t("auth.registerFailed"),
        getAuthErrorMessage(
          error instanceof Error ? error.message : "Network request failed",
        ),
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <KeyboardAvoidingView
      style={styles.flex}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <ScrollView
        contentContainerStyle={styles.container}
        keyboardShouldPersistTaps="handled"
      >
        <LanguageSwitch style={{ marginBottom: 16 }} />
        <View style={styles.header}>
          <Text style={styles.logo}>AvoraSport</Text>
          <Text style={styles.tagline}>{t("auth.taglineRegister")}</Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.title}>{t("auth.createAccount")}</Text>

          <SocialAuthButtons onBusyChange={setSocialBusy} />

          <Text style={styles.label}>{t("auth.email")}</Text>
          <TextInput
            style={styles.input}
            value={email}
            onChangeText={setEmail}
            placeholder={t("auth.emailPlaceholder")}
            placeholderTextColor="#555"
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
            returnKeyType="next"
          />

          <Text style={[styles.label, styles.labelSpacing]}>{t("auth.password")}</Text>
          <TextInput
            style={styles.input}
            value={password}
            onChangeText={setPassword}
            placeholder={t("auth.passwordPlaceholderMin")}
            placeholderTextColor="#555"
            secureTextEntry
            returnKeyType="next"
          />

          <Text style={[styles.label, styles.labelSpacing]}>
            {t("auth.confirmPassword")}
          </Text>
          <TextInput
            style={styles.input}
            value={confirmPassword}
            onChangeText={setConfirmPassword}
            placeholder="••••••••"
            placeholderTextColor="#555"
            secureTextEntry
            returnKeyType="done"
            onSubmitEditing={handleRegister}
          />

          <TouchableOpacity
            style={[styles.button, (loading || socialBusy) && styles.buttonDisabled]}
            onPress={handleRegister}
            disabled={loading || socialBusy}
            activeOpacity={0.8}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.buttonText}>{t("auth.register")}</Text>
            )}
          </TouchableOpacity>
        </View>

        <View style={styles.footer}>
          <Text style={styles.footerText}>{t("auth.haveAccount")}</Text>
          <TouchableOpacity onPress={() => router.push("/(auth)/login")}>
            <Text style={styles.footerLink}>{t("auth.login")}</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: {
    flex: 1,
    backgroundColor: "#121212",
  },
  container: {
    flexGrow: 1,
    padding: 24,
    justifyContent: "center",
  },
  header: {
    alignItems: "center",
    marginBottom: 48,
  },
  logo: {
    fontSize: 36,
    fontWeight: "800",
    color: "#0a7ea4",
    letterSpacing: 1,
  },
  tagline: {
    fontSize: 14,
    color: "#666",
    marginTop: 4,
  },
  card: {
    backgroundColor: "#1e1e1e",
    borderRadius: 20,
    padding: 24,
  },
  title: {
    fontSize: 22,
    fontWeight: "700",
    color: "#fff",
    marginBottom: 24,
  },
  label: {
    fontSize: 13,
    fontWeight: "600",
    color: "#aaa",
    textTransform: "uppercase",
    letterSpacing: 0.8,
    marginBottom: 8,
  },
  labelSpacing: {
    marginTop: 16,
  },
  input: {
    backgroundColor: "#2a2a2a",
    borderRadius: 10,
    padding: 14,
    fontSize: 16,
    color: "#fff",
    borderWidth: 1,
    borderColor: "#333",
  },
  button: {
    marginTop: 24,
    backgroundColor: "#0a7ea4",
    borderRadius: 12,
    padding: 16,
    alignItems: "center",
  },
  buttonDisabled: {
    opacity: 0.5,
  },
  buttonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "700",
  },
  footer: {
    flexDirection: "row",
    justifyContent: "center",
    marginTop: 24,
  },
  footerText: {
    color: "#666",
    fontSize: 14,
  },
  footerLink: {
    color: "#0a7ea4",
    fontSize: 14,
    fontWeight: "600",
  },
});
