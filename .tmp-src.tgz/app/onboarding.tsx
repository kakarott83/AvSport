import { router } from 'expo-router';
import { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';

import { DatePickerInput } from '@/components/DatePickerInput';
import { LanguageSwitch } from '@/components/LanguageSwitch';
import {
  CALORIE_GOAL_ADJUSTMENT,
  CALORIE_GOAL_LABELS,
  CALORIE_GOAL_TYPES,
  CalorieGoalType,
} from '@/hooks/useCalorieGoal';
import {
  ACTIVITY_LEVEL_LABELS,
  ACTIVITY_LEVELS,
  ActivityLevel,
  DEFAULT_ACTIVITY_LEVEL,
} from '@/lib/stepGoal';
import { useTranslation } from '@/lib/i18n';
import { parseDecimal, sanitizeDecimalInput } from '@/lib/profile';
import { supabase } from '@/services/supabaseClient';

const TOTAL_STEPS = 6;

export default function OnboardingScreen() {
  const { t } = useTranslation();
  const [step, setStep] = useState(1);
  const [name, setName] = useState('');
  const [gender, setGender] = useState<'male' | 'female' | null>(null);
  const [dob, setDob] = useState('');
  const [height, setHeight] = useState('');
  const [weight, setWeight] = useState('');
  const [calorieGoal, setCalorieGoal] = useState<CalorieGoalType>('maintain');
  const [activityLevel, setActivityLevel] = useState<ActivityLevel>(DEFAULT_ACTIVITY_LEVEL);
  const [saving, setSaving] = useState(false);

  // Google/Apple sign-in deliver the name in the user metadata — pre-fill it.
  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => {
      const meta = user?.user_metadata ?? {};
      const metaName = (meta.full_name ?? meta.name ?? '').toString().trim();
      if (metaName) setName((prev) => prev || metaName);
    });
  }, []);

  const isOptional = step > 1;
  const isLast = step === TOTAL_STEPS;

  function canAdvance() {
    if (step === 1) return name.trim().length >= 2;
    return true;
  }

  async function finish() {
    setSaving(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setSaving(false); return; }

    await supabase.from('profiles').upsert(
      {
        id: user.id,
        display_name: name.trim(),
        gender: gender ?? null,
        date_of_birth: dob || null,
        height_cm: height && !isNaN(parseDecimal(height)) ? parseDecimal(height) : null,
        weight_kg: weight && !isNaN(parseDecimal(weight)) ? parseDecimal(weight) : null,
        calorie_goal: calorieGoal,
        activity_level: activityLevel,
      },
      { onConflict: 'id' },
    );

    setSaving(false);
    router.replace('/(app)/(tabs)');
  }

  function next() {
    if (step < TOTAL_STEPS) {
      setStep((s) => s + 1);
    } else {
      finish();
    }
  }

  return (
    <KeyboardAvoidingView
      style={styles.flex}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <View style={styles.container}>
        {step === 1 && <LanguageSwitch style={{ marginBottom: 16 }} />}

        {/* Progress dots */}
        <View style={styles.dots}>
          {Array.from({ length: TOTAL_STEPS }).map((_, i) => (
            <View
              key={i}
              style={[styles.dot, i < step && styles.dotActive]}
            />
          ))}
        </View>

        {/* Step content */}
        <View style={styles.content}>
          {step === 1 && (
            <StepName name={name} onChange={setName} />
          )}
          {step === 2 && (
            <StepGender name={name} gender={gender} onChange={setGender} />
          )}
          {step === 3 && (
            <StepDob dob={dob} onChange={setDob} />
          )}
          {step === 4 && (
            <StepBody height={height} weight={weight} onHeight={setHeight} onWeight={setWeight} />
          )}
          {step === 5 && (
            <StepGoal goal={calorieGoal} onChange={setCalorieGoal} />
          )}
          {step === 6 && (
            <StepActivity activityLevel={activityLevel} onChange={setActivityLevel} />
          )}
        </View>

        {/* Actions */}
        <View style={styles.actions}>
          <TouchableOpacity
            style={[styles.nextBtn, !canAdvance() && styles.nextBtnDisabled]}
            onPress={next}
            disabled={!canAdvance() || saving}
            activeOpacity={0.85}
          >
            {saving
              ? <ActivityIndicator color="#121212" />
              : <Text style={styles.nextBtnText}>
                  {isLast ? t('onboarding.letsGo') : t('onboarding.next')}
                </Text>
            }
          </TouchableOpacity>

          {isOptional && (
            <TouchableOpacity onPress={next} activeOpacity={0.6} style={styles.skipBtn}>
              <Text style={styles.skipText}>{t('onboarding.skip')}</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

// ─── Step 1: Name ────────────────────────────────────────────────────────────

function StepName({ name, onChange }: { name: string; onChange: (v: string) => void }) {
  const { t } = useTranslation();
  return (
    <View>
      <Text style={styles.emoji}>👋</Text>
      <Text style={styles.heading}>{t('onboarding.welcome')}</Text>
      <Text style={styles.sub}>{t('onboarding.whatName')}</Text>
      <TextInput
        style={styles.input}
        value={name}
        onChangeText={onChange}
        placeholder={t('onboarding.namePlaceholder')}
        placeholderTextColor="#555"
        autoFocus
        returnKeyType="done"
      />
    </View>
  );
}

// ─── Step 2: Gender ───────────────────────────────────────────────────────────

function StepGender({
  name,
  gender,
  onChange,
}: {
  name: string;
  gender: 'male' | 'female' | null;
  onChange: (v: 'male' | 'female' | null) => void;
}) {
  const { t } = useTranslation();
  return (
    <View>
      <Text style={styles.emoji}>🙋</Text>
      <Text style={styles.heading}>{t('onboarding.hey', { name })}</Text>
      <Text style={styles.sub}>{t('onboarding.genderQuestion')}</Text>
      <View style={styles.chipRow}>
        {(['male', 'female'] as const).map((g) => (
          <TouchableOpacity
            key={g}
            style={[styles.chip, gender === g && styles.chipActive]}
            onPress={() => onChange(g)}
            activeOpacity={0.8}
          >
            <Text style={[styles.chipText, gender === g && styles.chipTextActive]}>
              {g === 'male' ? t('onboarding.male') : t('onboarding.female')}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

// ─── Step 3: Date of birth ───────────────────────────────────────────────────

function StepDob({ dob, onChange }: { dob: string; onChange: (v: string) => void }) {
  const { t } = useTranslation();
  return (
    <View>
      <Text style={styles.emoji}>🎂</Text>
      <Text style={styles.heading}>{t('onboarding.dobQuestion')}</Text>
      <Text style={styles.sub}>{t('onboarding.dobSub')}</Text>
      <DatePickerInput
        value={dob}
        onChange={onChange}
        label={t('profile.general.pickDateOfBirth')}
        showQuickDates={false}
      />
    </View>
  );
}

// ─── Step 4: Body data ───────────────────────────────────────────────────────

function StepBody({
  height,
  weight,
  onHeight,
  onWeight,
}: {
  height: string;
  weight: string;
  onHeight: (v: string) => void;
  onWeight: (v: string) => void;
}) {
  const { t } = useTranslation();
  return (
    <View>
      <Text style={styles.emoji}>📏</Text>
      <Text style={styles.heading}>{t('onboarding.bodyTitle')}</Text>
      <Text style={styles.sub}>{t('onboarding.bodySub')}</Text>
      <View style={styles.rowFields}>
        <View style={styles.rowField}>
          <Text style={styles.fieldLabel}>{t('profile.body.height')}</Text>
          <TextInput
            style={styles.input}
            value={height}
            onChangeText={(v) => onHeight(sanitizeDecimalInput(v))}
            placeholder="175"
            placeholderTextColor="#555"
            keyboardType="decimal-pad"
          />
        </View>
        <View style={styles.rowField}>
          <Text style={styles.fieldLabel}>{t('profile.body.weight')}</Text>
          <TextInput
            style={styles.input}
            value={weight}
            onChangeText={(v) => onWeight(sanitizeDecimalInput(v))}
            placeholder="75"
            placeholderTextColor="#555"
            keyboardType="decimal-pad"
          />
        </View>
      </View>
    </View>
  );
}

// ─── Step 5: Calorie goal ────────────────────────────────────────────────────

function StepGoal({
  goal,
  onChange,
}: {
  goal: CalorieGoalType;
  onChange: (v: CalorieGoalType) => void;
}) {
  const { t } = useTranslation();
  return (
    <View>
      <Text style={styles.emoji}>🎯</Text>
      <Text style={styles.heading}>{t('onboarding.goalQuestion')}</Text>
      <Text style={styles.sub}>{t('onboarding.goalSub')}</Text>
      <View style={styles.activityGrid}>
        {CALORIE_GOAL_TYPES.map((g) => {
          const adj = CALORIE_GOAL_ADJUSTMENT[g];
          return (
            <TouchableOpacity
              key={g}
              style={[styles.activityChip, goal === g && styles.goalChipActive]}
              onPress={() => onChange(g)}
              activeOpacity={0.8}
            >
              <Text style={[styles.activityChipText, goal === g && styles.chipTextActive]}>
                {CALORIE_GOAL_LABELS[g]} · {adj > 0 ? '+' : adj < 0 ? '−' : '±'}{Math.abs(adj)} kcal
              </Text>
              <Text style={styles.goalHint}>{t(`onboarding.goalHints.${g}`)}</Text>
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
}

// ─── Step 6: Activity level ──────────────────────────────────────────────────

function StepActivity({
  activityLevel,
  onChange,
}: {
  activityLevel: ActivityLevel;
  onChange: (v: ActivityLevel) => void;
}) {
  const { t } = useTranslation();
  return (
    <View>
      <Text style={styles.emoji}>⚡</Text>
      <Text style={styles.heading}>{t('onboarding.activityQuestion')}</Text>
      <Text style={styles.sub}>{t('onboarding.activitySub')}</Text>
      <View style={styles.activityGrid}>
        {ACTIVITY_LEVELS.map((level) => (
          <TouchableOpacity
            key={level}
            style={[styles.activityChip, activityLevel === level && styles.activityChipActive]}
            onPress={() => onChange(level)}
            activeOpacity={0.8}
          >
            <Text style={[styles.activityChipText, activityLevel === level && styles.activityChipTextActive]}>
              {ACTIVITY_LEVEL_LABELS[level]}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

// ─── Styles ──────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  flex:      { flex: 1, backgroundColor: '#121212' },
  container: { flex: 1, padding: 28, paddingTop: 64, justifyContent: 'space-between' },

  dots:    { flexDirection: 'row', gap: 8, marginBottom: 48 },
  dot:     { width: 8, height: 8, borderRadius: 4, backgroundColor: '#2a2a2a' },
  dotActive: { backgroundColor: '#00E5FF' },

  content: { flex: 1 },

  emoji:   { fontSize: 44, marginBottom: 16 },
  heading: { fontSize: 28, fontWeight: '800', color: '#fff', marginBottom: 10, lineHeight: 34 },
  sub:     { fontSize: 15, color: '#888', lineHeight: 22, marginBottom: 28 },

  input:   { backgroundColor: '#1e1e1e', borderRadius: 14, padding: 16, fontSize: 16, color: '#fff', borderWidth: 1, borderColor: '#2a2a2a', marginBottom: 12 },

  chipRow:      { flexDirection: 'row', gap: 12 },
  chip:         { flex: 1, paddingVertical: 16, borderRadius: 14, backgroundColor: '#1e1e1e', alignItems: 'center', borderWidth: 1, borderColor: '#2a2a2a' },
  chipActive:   { backgroundColor: '#0a3a3a', borderColor: '#00E5FF' },
  chipText:     { color: '#666', fontSize: 15, fontWeight: '600' },
  chipTextActive: { color: '#00E5FF' },

  rowFields: { flexDirection: 'row', gap: 12 },
  rowField:  { flex: 1 },
  fieldLabel: { color: '#888', fontSize: 12, fontWeight: '600', textTransform: 'uppercase', letterSpacing: 0.6, marginBottom: 8 },

  activityGrid:         { gap: 10 },
  activityChip:         { paddingVertical: 14, paddingHorizontal: 16, borderRadius: 14, backgroundColor: '#1e1e1e', borderWidth: 1, borderColor: '#2a2a2a' },
  activityChipActive:   { backgroundColor: '#1a1000', borderColor: '#FF9100' },
  activityChipText:     { color: '#666', fontSize: 14, fontWeight: '600' },
  activityChipTextActive: { color: '#FF9100' },
  goalChipActive:       { backgroundColor: '#0a3a3a', borderColor: '#00E5FF' },
  goalHint:             { color: '#555', fontSize: 12, marginTop: 4 },

  actions:  { paddingBottom: 16 },
  nextBtn:  { backgroundColor: '#00E5FF', borderRadius: 16, padding: 18, alignItems: 'center' },
  nextBtnDisabled: { opacity: 0.35 },
  nextBtnText: { color: '#121212', fontSize: 17, fontWeight: '700' },
  skipBtn:  { alignItems: 'center', paddingTop: 16 },
  skipText: { color: '#444', fontSize: 14 },
});
