import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { router } from 'expo-router';
import { useEffect, useRef, useState } from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Linking,
  Platform,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';

import { usePremium } from '@/hooks/usePremium';
import { restorePurchases } from '@/lib/purchases';

import { DatePickerInput } from '@/components/DatePickerInput';
import { Toast } from '@/components/Toast';
import * as Device from 'expo-device';

import {
  CALORIE_GOAL_ADJUSTMENT,
  CALORIE_GOAL_LABELS,
  CALORIE_GOAL_TYPES,
  CalorieGoalType,
} from '@/hooks/useCalorieGoal';
import { clearCredentials } from '@/lib/credentialStore';
import { checkAvailability, checkGoogleFitConnected, HealthManager, openHealthConnectSettings, requestPermissions } from '@/lib/healthManager';
import { syncHealthToSupabase } from '@/lib/healthSync';
import { clampStepper, formatDecimal, parseProfileFloat, parseProfileInt, sanitizeDecimalInput, STEPPER_BOUNDS, validateProfileForm } from '@/lib/profile';
import {
  ACTIVITY_LEVEL_LABELS,
  ACTIVITY_LEVELS,
  ActivityLevel,
  calculateDailyStepGoal,
  DEFAULT_ACTIVITY_LEVEL,
} from '@/lib/stepGoal';
import { formatNumber, LANGUAGE_NAMES, LANGUAGES, useTranslation, type Language } from '@/lib/i18n';
import { calculateWaterGoal } from '@/lib/waterGoal';
import { describeReminderSchedule, sanitizeWaterReminderSettings } from '@/lib/waterReminders';
import { syncWaterReminders } from '@/services/notifications/waterReminderService';
import { supabase } from '@/services/supabaseClient';

// ─────────────────────────────────────────
// Types
// ─────────────────────────────────────────

type ProfileForm = {
  display_name: string;
  gender: 'male' | 'female' | null;
  date_of_birth: string;
  height_cm: string;
  weight_kg: string;
  manual_calorie_offset: string;
  calorie_goal: CalorieGoalType;
  protein_per_kg: string;
  auto_adjust_calories: boolean;
  cycle_tracking_enabled: boolean;
  cycle_length_days: number;
  period_duration_days: number;
  cycle_calorie_bonus: number;
  cycle_period_reminder: boolean;
  cycle_fertile_reminder: boolean;
  activity_level: ActivityLevel;
  manual_step_goal: number;
  sync_health: boolean;
  water_goal_ml: number;
  water_reminder_enabled: boolean;
  water_reminder_start_hour: number;
  water_reminder_end_hour: number;
  water_reminder_interval_hours: number;
};

const EMPTY: ProfileForm = {
  display_name: '',
  gender: null,
  date_of_birth: '',
  height_cm: '',
  weight_kg: '',
  manual_calorie_offset: '0',
  calorie_goal: 'maintain',
  protein_per_kg: '2,0',
  auto_adjust_calories: false,
  cycle_tracking_enabled: false,
  cycle_length_days: 28,
  period_duration_days: 5,
  cycle_calorie_bonus: 0,
  cycle_period_reminder: false,
  cycle_fertile_reminder: false,
  activity_level: DEFAULT_ACTIVITY_LEVEL,
  manual_step_goal: 0,
  sync_health: false,
  water_goal_ml: 0,
  water_reminder_enabled: false,
  water_reminder_start_hour: 8,
  water_reminder_end_hour: 20,
  water_reminder_interval_hours: 2,
};

// ─────────────────────────────────────────
// Screen
// ─────────────────────────────────────────

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const { t, language, setLanguage } = useTranslation();
  const [form, setForm]       = useState<ProfileForm>(EMPTY);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving]   = useState(false);
  const [error, setError]     = useState('');
  const [toast, setToast]     = useState<string | null>(null);
  const [isNativeReady, setIsNativeReady] = useState(HealthManager.isNativeReady());
  const { isPremium, planLabel, refresh: refreshPremium } = usePremium();
  const [restoring, setRestoring] = useState(false);

  const cycleDebounce = useRef<ReturnType<typeof setTimeout> | null>(null);

  function patch<K extends keyof ProfileForm>(key: K, value: ProfileForm[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  useEffect(() => {
    HealthManager.init().then(() => setIsNativeReady(HealthManager.isNativeReady()));
  }, []);

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { setLoading(false); return; }

      const { data } = await supabase
        .from('profiles')
        .select(`display_name, gender, date_of_birth, height_cm, weight_kg,
                 manual_calorie_offset, calorie_goal, protein_per_kg, auto_adjust_calories,
                 cycle_tracking_enabled, cycle_length_days, period_duration_days,
                 cycle_calorie_bonus, cycle_period_reminder, cycle_fertile_reminder,
                 activity_level, manual_step_goal, sync_health,
                 water_goal_ml, water_reminder_enabled, water_reminder_start_hour,
                 water_reminder_end_hour, water_reminder_interval_hours`)
        .eq('id', user.id)
        .single();

      if (data) {
        setForm({
          display_name:            data.display_name ?? '',
          gender:                  data.gender ?? null,
          date_of_birth:           data.date_of_birth ?? '',
          height_cm:               formatDecimal(data.height_cm),
          weight_kg:               formatDecimal(data.weight_kg),
          manual_calorie_offset:   data.manual_calorie_offset != null ? String(data.manual_calorie_offset) : '0',
          calorie_goal:            (data.calorie_goal as CalorieGoalType) ?? 'maintain',
          protein_per_kg:          data.protein_per_kg != null ? formatDecimal(data.protein_per_kg) : '2,0',
          auto_adjust_calories:    data.auto_adjust_calories ?? false,
          cycle_tracking_enabled:  data.cycle_tracking_enabled ?? false,
          cycle_length_days:       data.cycle_length_days ?? 28,
          period_duration_days:    data.period_duration_days ?? 5,
          cycle_calorie_bonus:     data.cycle_calorie_bonus ?? 0,
          cycle_period_reminder:   data.cycle_period_reminder ?? false,
          cycle_fertile_reminder:  data.cycle_fertile_reminder ?? false,
          activity_level:          (data.activity_level as ActivityLevel) ?? DEFAULT_ACTIVITY_LEVEL,
          manual_step_goal:        data.manual_step_goal ?? 0,
          sync_health:             data.sync_health ?? false,
          water_goal_ml:                 data.water_goal_ml ?? 0,
          water_reminder_enabled:        data.water_reminder_enabled ?? false,
          water_reminder_start_hour:     data.water_reminder_start_hour ?? 8,
          water_reminder_end_hour:       data.water_reminder_end_hour ?? 20,
          water_reminder_interval_hours: data.water_reminder_interval_hours ?? 2,
        });
      }
      setLoading(false);
    })();
  }, []);

  // Schreibt einzelne Felder sofort (debounced von den Steppern aufgerufen),
  // ohne dass der Nutzer "Speichern" drücken muss.
  async function syncCycleField(patch: Partial<ProfileForm>) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const { error } = await supabase
      .from('profiles')
      .update(patch)
      .eq('id', user.id);
    if (error) console.log('[profile] field sync error:', error.message);
  }

  async function handleToggleHealth(enabled: boolean) {
    if (enabled && Platform.OS === 'ios') {
      try {
        const availability = await checkAvailability();
        if (!availability.available) {
          Alert.alert(
            t('profile.health.appleUnavailableTitle'),
            availability.reason === 'module_not_found'
              ? t('profile.health.appleModuleMissing')
              : t('profile.health.appleUnavailable'),
          );
          return;
        }
        const granted = await requestPermissions();
        if (!granted) {
          Alert.alert(
            t('profile.health.permissionMissingTitle'),
            t('profile.health.applePermissionMissing'),
          );
          return;
        }
      } catch (e) {
        console.error('[profile] handleToggleHealth (iOS) error:', e);
        Alert.alert(t('common.error'), t('profile.health.appleConnectFailed'));
        return;
      }
    } else if (enabled) {
      if (!Device.isDevice) {
        Alert.alert(
          t('profile.health.simulatorTitle'),
          t('profile.health.simulator'),
        );
        return;
      }

      if (!isNativeReady) {
        Alert.alert(
          t('profile.health.waitTitle'),
          t('profile.health.wait'),
        );
        return;
      }

      try {
        const availability = await checkAvailability();

        if (!availability.available) {
          if (availability.reason === 'sdk_unavailable') {
            Alert.alert(
              t('profile.health.notInstalledTitle'),
              t('profile.health.notInstalled'),
            );
          } else if (availability.reason === 'sdk_update_required') {
            Alert.alert(t('profile.health.outdatedTitle'), t('profile.health.outdated'));
          } else if (availability.reason === 'not_android') {
            Alert.alert(t('profile.health.notSupportedTitle'), t('profile.health.notSupported'));
          } else {
            Alert.alert(t('common.error'), t('profile.health.startFailed'));
          }
          return;
        }

        const granted = await requestPermissions();
        if (!granted) {
          Alert.alert(
            t('profile.health.deniedTitle'),
            t('profile.health.denied'),
            [
              { text: t('common.cancel'), style: 'cancel' },
              { text: t('profile.health.openHealthConnect'), onPress: () => openHealthConnectSettings() },
            ],
          );
          return;
        }

        const fitConnected = await checkGoogleFitConnected();
        if (!fitConnected) {
          Alert.alert(
            t('profile.health.googleFitTitle'),
            t('profile.health.googleFit'),
            [
              { text: t('common.understood') },
            ],
          );
        }
      } catch (e) {
        console.error('[profile] handleToggleHealth error:', e);
        Alert.alert(t('common.error'), t('profile.health.enableFailed'));
        return;
      }
    }

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { error: dbError } = await supabase
      .from('profiles')
      .update({ sync_health: enabled })
      .eq('id', user.id);

    if (dbError) {
      console.error('[profile] sync_health update failed:', dbError.message);
      patch('sync_health', !enabled);
      Alert.alert(
        t('profile.health.saveFailedTitle'),
        t('profile.health.saveFailed'),
      );
      return;
    }

    patch('sync_health', enabled);
    if (enabled) syncHealthToSupabase();
  }

  function onCycleToggle(enabled: boolean) {
    setForm((prev) => ({ ...prev, cycle_tracking_enabled: enabled }));
    syncCycleField({ cycle_tracking_enabled: enabled });
  }

  // Plant die täglichen Trink-Erinnerungen anhand des aktuellen Formularstands
  // neu. Best-effort — Fehler werden im Service geloggt, nicht hier.
  function resyncWaterReminders(f: ProfileForm) {
    const { goalMl } = calculateWaterGoal(
      f.weight_kg ? parseProfileFloat(f.weight_kg, 0) : null,
      f.water_goal_ml > 0 ? f.water_goal_ml : null,
      f.activity_level,
    );
    void syncWaterReminders({
      goalMl,
      settings: sanitizeWaterReminderSettings({
        enabled:       f.water_reminder_enabled,
        startHour:     f.water_reminder_start_hour,
        endHour:       f.water_reminder_end_hour,
        intervalHours: f.water_reminder_interval_hours,
      }),
    });
  }

  function onLanguageChange(lang: Language) {
    if (lang === language) return;
    setLanguage(lang);
    // Geplante Benachrichtigungen enthalten fertigen Text → in neuer Sprache neu planen.
    resyncWaterReminders(form);
  }

  function onWaterReminderToggle(enabled: boolean) {
    const updated = { ...form, water_reminder_enabled: enabled };
    setForm(updated);
    syncCycleField({ water_reminder_enabled: enabled });
    resyncWaterReminders(updated);
  }

  function stepperChange(
    field:
      | 'cycle_length_days'
      | 'period_duration_days'
      | 'cycle_calorie_bonus'
      | 'manual_step_goal'
      | 'water_goal_ml'
      | 'water_reminder_start_hour'
      | 'water_reminder_end_hour'
      | 'water_reminder_interval_hours',
    delta: number,
    min: number,
    max: number
  ) {
    setForm((prev) => {
      const next = clampStepper(prev[field] as number, delta, min, max);
      const updated = { ...prev, [field]: next };
      if (cycleDebounce.current) clearTimeout(cycleDebounce.current);
      cycleDebounce.current = setTimeout(() => {
        syncCycleField({ [field]: next });
        if (field.startsWith('water_')) resyncWaterReminders(updated);
      }, 800);
      return updated;
    });
  }

  async function handleSave() {
    setError('');
    const validation = validateProfileForm({ display_name: form.display_name });
    if (!validation.valid) { setError(validation.error); return; }

    setSaving(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setSaving(false); return; }

    const offset     = parseProfileInt(form.manual_calorie_offset, 0);
    const proteinPkg = parseProfileFloat(form.protein_per_kg, 2.0);

    const { error: dbErr } = await supabase.from('profiles').upsert(
      {
        id:                       user.id,
        display_name:             form.display_name.trim(),
        gender:                   form.gender,
        date_of_birth:            form.date_of_birth || null,
        height_cm:                form.height_cm ? parseProfileFloat(form.height_cm, 0) : null,
        weight_kg:                form.weight_kg ? parseProfileFloat(form.weight_kg, 0) : null,
        manual_calorie_offset:    offset,
        calorie_goal:             form.calorie_goal,
        protein_per_kg:           proteinPkg,
        auto_adjust_calories:     form.auto_adjust_calories,
        cycle_tracking_enabled:   form.cycle_tracking_enabled,
        cycle_length_days:        form.cycle_length_days,
        period_duration_days:     form.period_duration_days,
        cycle_calorie_bonus:      form.cycle_calorie_bonus,
        cycle_period_reminder:    form.cycle_period_reminder,
        cycle_fertile_reminder:   form.cycle_fertile_reminder,
        activity_level:           form.activity_level,
        manual_step_goal:         form.manual_step_goal > 0 ? form.manual_step_goal : null,
        sync_health:              form.sync_health,
        water_goal_ml:                 form.water_goal_ml > 0 ? form.water_goal_ml : null,
        water_reminder_enabled:        form.water_reminder_enabled,
        water_reminder_start_hour:     form.water_reminder_start_hour,
        water_reminder_end_hour:       form.water_reminder_end_hour,
        water_reminder_interval_hours: form.water_reminder_interval_hours,
      },
      { onConflict: 'id' }
    );

    setSaving(false);
    if (dbErr) { setError(dbErr.message); return; }
    resyncWaterReminders(form);
    setToast(t('profile.saved'));
  }

  async function handleLogout() {
    await clearCredentials();
    await supabase.auth.signOut();
  }

  function manageSubscription() {
    const url = Platform.OS === 'ios'
      ? 'https://apps.apple.com/account/subscriptions'
      : 'https://play.google.com/store/account/subscriptions';
    Linking.openURL(url).catch(() => {});
  }

  async function handleRestore() {
    if (restoring) return;
    setRestoring(true);
    try {
      const ok = await restorePurchases();
      await refreshPremium();
      setToast(ok ? t('profile.premium.restored') : t('profile.premium.noSubscription'));
    } catch {
      setToast(t('profile.premium.restoreFailed'));
    } finally {
      setRestoring(false);
    }
  }

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color="#00E5FF" />
      </View>
    );
  }

  const waterGoal = calculateWaterGoal(
    form.weight_kg ? parseProfileFloat(form.weight_kg, 0) : null,
    form.water_goal_ml > 0 ? form.water_goal_ml : null,
    form.activity_level,
  );

  return (
    <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView
        contentContainerStyle={[styles.container, { paddingTop: insets.top + 16 }]}
        showsVerticalScrollIndicator={false}
      >

        {/* ── Sprache ── */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>{t('profile.language.title')}</Text>
          <Text style={styles.hint}>{t('profile.language.hint')}</Text>
          <View style={[styles.chipRow, { marginBottom: 0 }]}>
            {LANGUAGES.map((lang) => (
              <TouchableOpacity
                key={lang}
                style={[styles.chip, language === lang && styles.chipActive]}
                onPress={() => onLanguageChange(lang)}
                activeOpacity={0.8}>
                <Text style={[styles.chipText, language === lang && styles.chipTextActive]}>
                  {LANGUAGE_NAMES[lang]}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* ── Allgemein ── */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>{t('profile.general.title')}</Text>

          <Text style={styles.label}>{t('profile.general.displayName')}</Text>
          <TextInput
            style={styles.input}
            value={form.display_name}
            onChangeText={(v) => patch('display_name', v)}
            placeholder={t('profile.general.displayNamePlaceholder')}
            placeholderTextColor="#555"
          />

          <Text style={styles.label}>{t('profile.general.gender')}</Text>
          <View style={styles.chipRow}>
            {(['male', 'female'] as const).map((g) => (
              <TouchableOpacity
                key={g}
                style={[styles.chip, form.gender === g && styles.chipActive]}
                onPress={() => patch('gender', g)}
                activeOpacity={0.8}>
                <Text style={[styles.chipText, form.gender === g && styles.chipTextActive]}>
                  {g === 'male' ? t('profile.general.male') : t('profile.general.female')}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text style={styles.label}>{t('profile.general.dateOfBirth')}</Text>
          <DatePickerInput
            value={form.date_of_birth}
            onChange={(v) => patch('date_of_birth', v)}
            label={t('profile.general.pickDateOfBirth')}
            showQuickDates={false}
          />
        </View>

        {/* ── Körperdaten ── */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>{t('profile.body.title')}</Text>
          <View style={styles.rowFields}>
            <View style={styles.rowField}>
              <Text style={styles.label}>{t('profile.body.height')}</Text>
              <TextInput
                style={styles.input}
                value={form.height_cm}
                onChangeText={(v) => patch('height_cm', sanitizeDecimalInput(v))}
                placeholder="175"
                placeholderTextColor="#555"
                keyboardType="decimal-pad"
              />
            </View>
            <View style={styles.rowField}>
              <Text style={styles.label}>{t('profile.body.weight')}</Text>
              <TextInput
                style={styles.input}
                value={form.weight_kg}
                onChangeText={(v) => patch('weight_kg', sanitizeDecimalInput(v))}
                placeholder={t('profile.body.weightPlaceholder')}
                placeholderTextColor="#555"
                keyboardType="decimal-pad"
              />
            </View>
          </View>
        </View>

        {/* ── Kalorien-Ziel ── */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>{t('profile.calorieGoal.title')}</Text>
          <Text style={styles.hint}>{t('profile.calorieGoal.hint')}</Text>
          <Text style={styles.label}>{t('profile.calorieGoal.myGoal')}</Text>
          <View style={styles.chipRow}>
            {CALORIE_GOAL_TYPES.map((goal) => (
              <TouchableOpacity
                key={goal}
                style={[styles.chip, styles.chipNarrow, form.calorie_goal === goal && styles.chipActive]}
                onPress={() => patch('calorie_goal', goal)}
                activeOpacity={0.8}>
                <Text style={[styles.chipText, form.calorie_goal === goal && styles.chipTextActive]}>
                  {CALORIE_GOAL_LABELS[goal]}
                </Text>
                <Text style={[styles.chipSub, form.calorie_goal === goal && styles.chipTextActive]}>
                  {CALORIE_GOAL_ADJUSTMENT[goal] > 0 ? '+' : CALORIE_GOAL_ADJUSTMENT[goal] < 0 ? '−' : '±'}
                  {Math.abs(CALORIE_GOAL_ADJUSTMENT[goal])} kcal
                </Text>
              </TouchableOpacity>
            ))}
          </View>
          <Text style={styles.label}>{t('profile.calorieGoal.offset')}</Text>
          <Text style={styles.hint}>{t('profile.calorieGoal.offsetHint')}</Text>
          <TextInput
            style={styles.input}
            value={form.manual_calorie_offset}
            onChangeText={(v) => patch('manual_calorie_offset', v.replace(/[^0-9-]/g, ''))}
            placeholder="0"
            placeholderTextColor="#555"
            keyboardType="default"
          />
        </View>

        {/* ── Ziele & Performance ── */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>{t('profile.performance.title')}</Text>

          <Text style={styles.label}>{t('profile.performance.protein')}</Text>
          <Text style={styles.hint}>{t('profile.performance.proteinHint')}</Text>
          <TextInput
            style={styles.input}
            value={form.protein_per_kg}
            onChangeText={(v) => patch('protein_per_kg', sanitizeDecimalInput(v))}
            placeholder={t('profile.performance.proteinPlaceholder')}
            placeholderTextColor="#555"
            keyboardType="decimal-pad"
          />

          <Text style={styles.label}>{t('profile.performance.trainingCalories')}</Text>
          <Text style={styles.hint}>{t('profile.performance.trainingCaloriesHint')}</Text>
          <View style={styles.toggleRow}>
            <Text style={styles.toggleLabel}>
              {form.auto_adjust_calories ? t('common.enabled') : t('common.disabled')}
            </Text>
            <Switch
              value={form.auto_adjust_calories}
              onValueChange={(v) => patch('auto_adjust_calories', v)}
              trackColor={{ false: '#2a2a2a', true: '#0a3a3a' }}
              thumbColor={form.auto_adjust_calories ? '#00E5FF' : '#555'}
            />
          </View>
        </View>

        {/* ── Schritt-Ziel ── */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>{t('profile.steps.title')}</Text>
          <Text style={styles.hint}>
            {t('profile.steps.hintBefore')}{' '}
            <Text style={{ color: '#FF9100', fontWeight: '700' }}>
              {formatNumber(calculateDailyStepGoal(form.activity_level, form.manual_step_goal > 0 ? form.manual_step_goal : null))}
            </Text>{' '}
            {t('profile.steps.hintAfter')}
          </Text>

          <Text style={styles.label}>{t('profile.steps.activityLevel')}</Text>
          <View style={styles.chipRow}>
            {ACTIVITY_LEVELS.map((level) => (
              <TouchableOpacity
                key={level}
                style={[styles.chip, styles.chipNarrow, form.activity_level === level && styles.chipActiveOrange]}
                onPress={() => patch('activity_level', level)}
                activeOpacity={0.8}>
                <Text style={[styles.chipText, form.activity_level === level && styles.chipTextOrange]}>
                  {ACTIVITY_LEVEL_LABELS[level]}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text style={styles.label}>{t('profile.steps.manualGoal')}</Text>
          <Text style={styles.hint}>{t('profile.steps.manualGoalHint')}</Text>
          <Stepper
            value={form.manual_step_goal}
            unit={t('common.units.steps')}
            step={STEPPER_BOUNDS.manual_step_goal.step}
            min={STEPPER_BOUNDS.manual_step_goal.min}
            max={STEPPER_BOUNDS.manual_step_goal.max}
            onDecrement={() => stepperChange('manual_step_goal', -STEPPER_BOUNDS.manual_step_goal.step, STEPPER_BOUNDS.manual_step_goal.min, STEPPER_BOUNDS.manual_step_goal.max)}
            onIncrement={() => stepperChange('manual_step_goal', +STEPPER_BOUNDS.manual_step_goal.step, STEPPER_BOUNDS.manual_step_goal.min, STEPPER_BOUNDS.manual_step_goal.max)}
            accentColor="#FF9100"
          />
        </View>

        {/* ── Wasser ── */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>{t('profile.water.title')}</Text>
          <Text style={styles.hint}>
            {t('profile.water.hintBefore')}{' '}
            <Text style={{ color: '#29B6F6', fontWeight: '700' }}>
              {formatNumber(waterGoal.goalMl)} ml
            </Text>{' '}
            {waterGoal.source === 'user' ? t('profile.water.sourceUser') : t('profile.water.sourceAuto')}
          </Text>

          <Text style={styles.label}>{t('profile.steps.manualGoal')}</Text>
          <Text style={styles.hint}>{t('profile.water.manualGoalHint')}</Text>
          <Stepper
            value={form.water_goal_ml}
            unit="ml"
            step={STEPPER_BOUNDS.water_goal_ml.step}
            min={STEPPER_BOUNDS.water_goal_ml.min}
            max={STEPPER_BOUNDS.water_goal_ml.max}
            onDecrement={() => stepperChange('water_goal_ml', -STEPPER_BOUNDS.water_goal_ml.step, STEPPER_BOUNDS.water_goal_ml.min, STEPPER_BOUNDS.water_goal_ml.max)}
            onIncrement={() => stepperChange('water_goal_ml', +STEPPER_BOUNDS.water_goal_ml.step, STEPPER_BOUNDS.water_goal_ml.min, STEPPER_BOUNDS.water_goal_ml.max)}
            accentColor="#29B6F6"
          />

          <View style={styles.separator} />

          <View style={[styles.toggleRow, { marginBottom: form.water_reminder_enabled ? 20 : 0 }]}>
            <View style={styles.toggleLabelGroup}>
              <Text style={styles.toggleLabel}>{t('profile.water.reminders')}</Text>
              <Text style={styles.toggleSub}>
                {form.water_reminder_enabled ? describeReminderSchedule({
                  enabled: true,
                  startHour: form.water_reminder_start_hour,
                  endHour: form.water_reminder_end_hour,
                  intervalHours: form.water_reminder_interval_hours,
                }) : t('common.inactive')}
              </Text>
            </View>
            <Switch
              value={form.water_reminder_enabled}
              onValueChange={onWaterReminderToggle}
              trackColor={{ false: '#2a2a2a', true: '#0a2a3a' }}
              thumbColor={form.water_reminder_enabled ? '#29B6F6' : '#555'}
            />
          </View>

          {form.water_reminder_enabled && (
            <>
              <Text style={styles.label}>{t('profile.water.firstReminder')}</Text>
              <Stepper
                value={form.water_reminder_start_hour}
                unit={t('common.units.oClock')}
                min={STEPPER_BOUNDS.water_reminder_start_hour.min}
                max={STEPPER_BOUNDS.water_reminder_start_hour.max}
                onDecrement={() => stepperChange('water_reminder_start_hour', -1, STEPPER_BOUNDS.water_reminder_start_hour.min, STEPPER_BOUNDS.water_reminder_start_hour.max)}
                onIncrement={() => stepperChange('water_reminder_start_hour', +1, STEPPER_BOUNDS.water_reminder_start_hour.min, STEPPER_BOUNDS.water_reminder_start_hour.max)}
                accentColor="#29B6F6"
              />

              <View style={styles.separator} />

              <Text style={styles.label}>{t('profile.water.lastReminder')}</Text>
              <Stepper
                value={form.water_reminder_end_hour}
                unit={t('common.units.oClock')}
                min={STEPPER_BOUNDS.water_reminder_end_hour.min}
                max={STEPPER_BOUNDS.water_reminder_end_hour.max}
                onDecrement={() => stepperChange('water_reminder_end_hour', -1, STEPPER_BOUNDS.water_reminder_end_hour.min, STEPPER_BOUNDS.water_reminder_end_hour.max)}
                onIncrement={() => stepperChange('water_reminder_end_hour', +1, STEPPER_BOUNDS.water_reminder_end_hour.min, STEPPER_BOUNDS.water_reminder_end_hour.max)}
                accentColor="#29B6F6"
              />

              <View style={styles.separator} />

              <Text style={styles.label}>{t('profile.water.interval')}</Text>
              <Text style={styles.hint}>{t('profile.water.intervalHint')}</Text>
              <Stepper
                value={form.water_reminder_interval_hours}
                unit={t('common.units.hoursShort')}
                min={STEPPER_BOUNDS.water_reminder_interval_hours.min}
                max={STEPPER_BOUNDS.water_reminder_interval_hours.max}
                onDecrement={() => stepperChange('water_reminder_interval_hours', -1, STEPPER_BOUNDS.water_reminder_interval_hours.min, STEPPER_BOUNDS.water_reminder_interval_hours.max)}
                onIncrement={() => stepperChange('water_reminder_interval_hours', +1, STEPPER_BOUNDS.water_reminder_interval_hours.min, STEPPER_BOUNDS.water_reminder_interval_hours.max)}
                accentColor="#29B6F6"
              />
            </>
          )}
        </View>

        {/* ── Zyklus-Tracking (nur bei Geschlecht "weiblich") ── */}
        {form.gender === 'female' && (
        <View style={styles.card}>
          <Text style={styles.cardTitle}>{t('profile.cycle.title')}</Text>
          <Text style={styles.hint}>{t('profile.cycle.hint')}</Text>

          <View style={[styles.toggleRow, { marginBottom: form.cycle_tracking_enabled ? 20 : 0 }]}>
            <View style={styles.toggleLabelGroup}>
              <Text style={styles.toggleLabel}>{t('profile.cycle.toggle')}</Text>
              <Text style={styles.toggleSub}>{form.cycle_tracking_enabled ? t('common.active') : t('common.inactive')}</Text>
            </View>
            <Switch
              value={form.cycle_tracking_enabled}
              onValueChange={onCycleToggle}
              trackColor={{ false: '#2a2a2a', true: '#3a0d0d' }}
              thumbColor={form.cycle_tracking_enabled ? '#FF5252' : '#555'}
            />
          </View>

          {form.cycle_tracking_enabled && (
            <>
              <Text style={styles.label}>{t('profile.cycle.cycleLength')}</Text>
              <Text style={styles.hint}>{t('profile.cycle.cycleLengthHint')}</Text>
              <Stepper
                value={form.cycle_length_days}
                unit={t('common.units.days')}
                min={STEPPER_BOUNDS.cycle_length_days.min}
                max={STEPPER_BOUNDS.cycle_length_days.max}
                onDecrement={() => stepperChange('cycle_length_days', -STEPPER_BOUNDS.cycle_length_days.step, STEPPER_BOUNDS.cycle_length_days.min, STEPPER_BOUNDS.cycle_length_days.max)}
                onIncrement={() => stepperChange('cycle_length_days', +STEPPER_BOUNDS.cycle_length_days.step, STEPPER_BOUNDS.cycle_length_days.min, STEPPER_BOUNDS.cycle_length_days.max)}
              />

              <View style={styles.separator} />

              <Text style={styles.label}>{t('profile.cycle.periodDuration')}</Text>
              <Text style={styles.hint}>{t('profile.cycle.periodDurationHint')}</Text>
              <Stepper
                value={form.period_duration_days}
                unit={t('common.units.days')}
                min={STEPPER_BOUNDS.period_duration_days.min}
                max={STEPPER_BOUNDS.period_duration_days.max}
                onDecrement={() => stepperChange('period_duration_days', -STEPPER_BOUNDS.period_duration_days.step, STEPPER_BOUNDS.period_duration_days.min, STEPPER_BOUNDS.period_duration_days.max)}
                onIncrement={() => stepperChange('period_duration_days', +STEPPER_BOUNDS.period_duration_days.step, STEPPER_BOUNDS.period_duration_days.min, STEPPER_BOUNDS.period_duration_days.max)}
              />

              <View style={styles.separator} />

              <Text style={styles.label}>{t('profile.cycle.calorieBonus')}</Text>
              <Text style={styles.hint}>{t('profile.cycle.calorieBonusHint')}</Text>
              <Stepper
                value={form.cycle_calorie_bonus}
                unit="kcal"
                step={STEPPER_BOUNDS.cycle_calorie_bonus.step}
                min={STEPPER_BOUNDS.cycle_calorie_bonus.min}
                max={STEPPER_BOUNDS.cycle_calorie_bonus.max}
                onDecrement={() => stepperChange('cycle_calorie_bonus', -STEPPER_BOUNDS.cycle_calorie_bonus.step, STEPPER_BOUNDS.cycle_calorie_bonus.min, STEPPER_BOUNDS.cycle_calorie_bonus.max)}
                onIncrement={() => stepperChange('cycle_calorie_bonus', +STEPPER_BOUNDS.cycle_calorie_bonus.step, STEPPER_BOUNDS.cycle_calorie_bonus.min, STEPPER_BOUNDS.cycle_calorie_bonus.max)}
                accentColor="#FF9100"
              />

              <View style={styles.separator} />

              <Text style={styles.label}>{t('profile.cycle.reminders')}</Text>
              <View style={styles.toggleRow}>
                <View style={styles.toggleLabelGroup}>
                  <Text style={styles.toggleLabel}>{t('profile.cycle.periodStart')}</Text>
                  <Text style={styles.toggleSub}>{t('profile.cycle.periodStartSub')}</Text>
                </View>
                <Switch
                  value={form.cycle_period_reminder}
                  onValueChange={(v) => { patch('cycle_period_reminder', v); syncCycleField({ cycle_period_reminder: v }); }}
                  trackColor={{ false: '#2a2a2a', true: '#3a0d0d' }}
                  thumbColor={form.cycle_period_reminder ? '#FF5252' : '#555'}
                />
              </View>
              <View style={[styles.toggleRow, { marginTop: 10 }]}>
                <View style={styles.toggleLabelGroup}>
                  <Text style={styles.toggleLabel}>{t('profile.cycle.fertileWindow')}</Text>
                  <Text style={styles.toggleSub}>{t('profile.cycle.fertileWindowSub')}</Text>
                </View>
                <Switch
                  value={form.cycle_fertile_reminder}
                  onValueChange={(v) => { patch('cycle_fertile_reminder', v); syncCycleField({ cycle_fertile_reminder: v }); }}
                  trackColor={{ false: '#2a2a2a', true: '#0d3a1a' }}
                  thumbColor={form.cycle_fertile_reminder ? '#4CAF50' : '#555'}
                />
              </View>

              <TouchableOpacity style={styles.cycleLinkRow} onPress={() => router.push('/(app)/(tabs)/calendar')} activeOpacity={0.7}>
                <Text style={styles.cycleLinkText}>{t('profile.cycle.toCalendar')}</Text>
                <MaterialIcons name="chevron-right" size={20} color="#00E5FF" />
              </TouchableOpacity>
            </>
          )}
        </View>
        )}

        {/* ── Geräte & Synchronisation ── */}
        {Platform.OS !== 'web' && (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>{t('profile.devices.title')}</Text>
            <Text style={styles.hint}>
              {Platform.OS === 'ios'
                ? t('profile.devices.hintIos')
                : t('profile.devices.hintAndroid')}
            </Text>
            <View style={styles.toggleRow}>
              <View style={styles.toggleLabelGroup}>
                <Text style={styles.toggleLabel}>
                  {Platform.OS === 'ios' ? '🍎 ' : '🏃 '}{t('profile.devices.share')}
                </Text>
                <Text style={styles.toggleSub}>
                  {form.sync_health
                    ? Platform.OS === 'ios' ? t('profile.devices.connectedIos') : t('profile.devices.connectedAndroid')
                    : t('profile.devices.notConnected')}
                </Text>
              </View>
              <Switch
                value={form.sync_health}
                onValueChange={handleToggleHealth}
                disabled={Platform.OS === 'android' && !isNativeReady}
                trackColor={{ false: '#2a2a2a', true: '#0a3a3a' }}
                thumbColor={Platform.OS === 'android' && !isNativeReady ? '#333' : form.sync_health ? '#00E5FF' : '#555'}
              />
            </View>
          </View>
        )}

        {error ? <Text style={styles.error}>{error}</Text> : null}

        <TouchableOpacity
          style={[styles.saveBtn, saving && styles.saveBtnDisabled]}
          onPress={handleSave}
          disabled={saving}
          activeOpacity={0.8}>
          {saving
            ? <ActivityIndicator color="#121212" />
            : <>
                <MaterialIcons name="check" size={18} color="#121212" />
                <Text style={styles.saveBtnText}>{t('common.save')}</Text>
              </>
          }
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.menuRow}
          onPress={() => (isPremium ? manageSubscription() : router.push('/paywall'))}
          activeOpacity={0.7}>
          <MaterialIcons name={isPremium ? 'workspace-premium' : 'bolt'} size={18} color="#00E5FF" />
          <View style={{ flex: 1 }}>
            <Text style={styles.menuRowText}>{t('profile.premium.title')}</Text>
            <Text style={styles.menuRowSub}>
              {isPremium
                ? planLabel
                  ? t('profile.premium.activePlan', { plan: planLabel })
                  : t('profile.premium.activeManage')
                : t('profile.premium.free')}
            </Text>
          </View>
          <MaterialIcons name="chevron-right" size={20} color="#555" />
        </TouchableOpacity>

        {!isPremium && (
          <TouchableOpacity
            style={[styles.menuRow, { marginTop: 10 }]}
            onPress={handleRestore}
            disabled={restoring}
            activeOpacity={0.7}>
            <MaterialIcons name="restore" size={18} color="#888" />
            <Text style={[styles.menuRowText, { color: '#aaa' }]}>
              {restoring ? t('profile.premium.checking') : t('profile.premium.restore')}
            </Text>
          </TouchableOpacity>
        )}

        <TouchableOpacity
          style={styles.menuRow}
          onPress={() => router.push('/features')}
          activeOpacity={0.7}>
          <MaterialIcons name="lightbulb-outline" size={18} color="#00E5FF" />
          <Text style={styles.menuRowText}>{t('profile.menu.features')}</Text>
          <MaterialIcons name="chevron-right" size={20} color="#555" />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.menuRow}
          onPress={() => router.push('/feedback')}
          activeOpacity={0.7}>
          <MaterialIcons name="chat-bubble-outline" size={18} color="#00E5FF" />
          <Text style={styles.menuRowText}>{t('profile.menu.feedback')}</Text>
          <MaterialIcons name="chevron-right" size={20} color="#555" />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.logoutBtn}
          onPress={handleLogout}
          activeOpacity={0.7}>
          <MaterialIcons name="logout" size={16} color="#666" />
          <Text style={styles.logoutBtnText}>{t('profile.menu.logout')}</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.legalLink}
          onPress={() => router.push('/legal')}
          activeOpacity={0.7}>
          <Text style={styles.legalLinkText}>{t('profile.menu.legal')}</Text>
        </TouchableOpacity>

      </ScrollView>

      {toast && (
        <Toast message={toast} type="success" duration={1600} onDismiss={() => setToast(null)} />
      )}
    </KeyboardAvoidingView>
  );
}

// ─────────────────────────────────────────
// Stepper component
// ─────────────────────────────────────────

function Stepper({
  value,
  unit,
  step = 1,
  min,
  max,
  onDecrement,
  onIncrement,
  accentColor = '#00E5FF',
}: {
  value: number;
  unit: string;
  step?: number;
  min: number;
  max: number;
  onDecrement: () => void;
  onIncrement: () => void;
  accentColor?: string;
}) {
  const atMin = value <= min;
  const atMax = value >= max;
  return (
    <View style={stepStyles.row}>
      <TouchableOpacity
        style={[stepStyles.btn, atMin && stepStyles.btnDisabled]}
        onPress={onDecrement}
        disabled={atMin}
        activeOpacity={0.7}>
        <Text style={[stepStyles.btnText, atMin && stepStyles.btnTextDisabled]}>−</Text>
      </TouchableOpacity>

      <View style={[stepStyles.valueBox, { borderColor: accentColor + '55' }]}>
        <Text style={[stepStyles.valueText, { color: accentColor }]}>{value}</Text>
        <Text style={stepStyles.unitText}>{unit}</Text>
      </View>

      <TouchableOpacity
        style={[stepStyles.btn, atMax && stepStyles.btnDisabled]}
        onPress={onIncrement}
        disabled={atMax}
        activeOpacity={0.7}>
        <Text style={[stepStyles.btnText, atMax && stepStyles.btnTextDisabled]}>+</Text>
      </TouchableOpacity>
    </View>
  );
}

const stepStyles = StyleSheet.create({
  row:         { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 8 },
  btn:         { width: 44, height: 44, borderRadius: 12, backgroundColor: '#2a2a2a', borderWidth: 1, borderColor: '#333', alignItems: 'center', justifyContent: 'center' },
  btnDisabled: { opacity: 0.3 },
  btnText:     { color: '#fff', fontSize: 22, fontWeight: '300', lineHeight: 26 },
  btnTextDisabled: { color: '#555' },
  valueBox:    { flex: 1, flexDirection: 'row', alignItems: 'baseline', justifyContent: 'center', gap: 5, backgroundColor: '#1a1a1a', borderRadius: 12, borderWidth: 1, paddingVertical: 10 },
  valueText:   { fontSize: 22, fontWeight: '800' },
  unitText:    { color: '#666', fontSize: 12, fontWeight: '600' },
});

// ─────────────────────────────────────────
// Styles
// ─────────────────────────────────────────

const styles = StyleSheet.create({
  flex:      { flex: 1, backgroundColor: '#121212' },
  center:    { flex: 1, backgroundColor: '#121212', justifyContent: 'center', alignItems: 'center' },
  container: { padding: 20, paddingTop: 16, paddingBottom: 48 },

  card:      { backgroundColor: '#1e1e1e', borderRadius: 20, padding: 20, marginBottom: 16, borderWidth: 1, borderColor: '#2a2a2a' },
  cardTitle: { color: '#e0e0e0', fontSize: 13, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.9, marginBottom: 16 },

  label: { color: '#ccc', fontSize: 12, fontWeight: '600', textTransform: 'uppercase', letterSpacing: 0.7, marginBottom: 8 },
  hint:  { color: '#888', fontSize: 13, lineHeight: 20, marginBottom: 16 },

  input: { backgroundColor: '#2a2a2a', borderRadius: 10, padding: 14, fontSize: 15, color: '#fff', borderWidth: 1, borderColor: '#333', marginBottom: 16 },

  chipRow:        { flexDirection: 'row', gap: 10, marginBottom: 16 },
  chip:           { flex: 1, paddingVertical: 11, borderRadius: 10, backgroundColor: '#2a2a2a', alignItems: 'center', borderWidth: 1, borderColor: '#333' },
  chipActive:     { backgroundColor: '#0a3a3a', borderColor: '#00E5FF' },
  chipActiveOrange: { backgroundColor: '#1a1000', borderColor: '#FF9100' },
  chipNarrow:     { paddingHorizontal: 4 },
  chipText:       { color: '#666', fontSize: 13, fontWeight: '600', textAlign: 'center' },
  chipTextActive: { color: '#00E5FF' },
  chipTextOrange: { color: '#FF9100' },
  chipSub:        { color: '#555', fontSize: 11, marginTop: 2 },

  rowFields: { flexDirection: 'row', gap: 12 },
  rowField:  { flex: 1 },

  toggleRow:        { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#2a2a2a', borderRadius: 10, paddingHorizontal: 16, paddingVertical: 12, borderWidth: 1, borderColor: '#333' },
  toggleLabelGroup: { gap: 2 },
  toggleLabel:      { color: '#aaa', fontSize: 14, fontWeight: '600' },
  toggleSub:        { color: '#555', fontSize: 11 },

  cycleLinkRow:  { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 16, paddingVertical: 4 },
  cycleLinkText: { color: '#00E5FF', fontSize: 14, fontWeight: '700' },

  separator: { height: 1, backgroundColor: '#2a2a2a', marginVertical: 16 },

  error:          { color: '#c0392b', fontSize: 13, textAlign: 'center', marginBottom: 16 },
  saveBtn:        { backgroundColor: '#00E5FF', borderRadius: 14, padding: 16, alignItems: 'center', flexDirection: 'row', justifyContent: 'center', gap: 8 },
  saveBtnDisabled: { opacity: 0.5 },
  saveBtnText:    { color: '#121212', fontSize: 16, fontWeight: '700' },

  logoutBtn:     { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, marginTop: 20, padding: 12 },
  logoutBtnText: { color: '#666', fontSize: 13 },
  legalLink:     { alignItems: 'center', paddingVertical: 8 },
  legalLinkText: { color: '#555', fontSize: 12, textDecorationLine: 'underline' },
  menuRow: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    backgroundColor: '#1e1e1e', borderRadius: 12, borderWidth: 1, borderColor: '#2a2a2a',
    paddingHorizontal: 16, paddingVertical: 14, marginTop: 20,
  },
  menuRowText: { flex: 1, color: '#eee', fontSize: 14, fontWeight: '600' },
  menuRowSub: { color: '#888', fontSize: 12, marginTop: 2 },
});
