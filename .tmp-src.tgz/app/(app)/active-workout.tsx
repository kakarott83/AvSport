import { router, useLocalSearchParams } from 'expo-router';
import { useEffect, useRef, useState } from 'react';
import {
  Animated,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';

import { ExerciseDetailModal } from '@/components/ExerciseDetailModal';
import { estimateWorkoutKcal } from '@/lib/calorieBurn';
import { t, useTranslation } from '@/lib/i18n';
import { playBeep } from '@/services/audioService';
import { formatDecimal, parseDecimal, sanitizeDecimalInput } from '@/lib/profile';
import { supabase } from '@/services/supabaseClient';

// ─────────────────────────────────────────
// Types
// ─────────────────────────────────────────

type PlanExercise = {
  id: string;
  exercise_name: string;
  description: string | null;
  muscle_group: string | null;
  equipment_type: string | null;
  sets: number;
  reps: number;
  target_duration: number | null;
  target_weight_kg: number | null;
  rest_seconds: number | null;
  name_en: string | null;
  short: string | null;
  detail_markdown: string | null;
  instructions: string[] | null;
  modifications: { beginner: string; advanced: string } | null;
  safety: string | null;
  tips: string[] | null;
};

type PlanMeta = {
  is_circuit: boolean;
  circuit_rounds: number;
  rest_between_exercises_seconds: number;
  rest_between_rounds_seconds: number;
};

type PlanDayInfo = {
  id: string;
  label: string;
  warmup: string | null;
  cooldown: string | null;
};

type LoggedSet = {
  id: string;
  exercise: string;
  weight: string;
  reps: string;
  duration: number;
};

// ─────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────

function formatTime(s: number): string {
  const m = Math.floor(s / 60).toString().padStart(2, '0');
  const sec = (s % 60).toString().padStart(2, '0');
  return `${m}:${sec}`;
}

// ─────────────────────────────────────────
// Countdown-Kreis (Two-half rotation, pure RN Animated)
// ─────────────────────────────────────────

function CountdownRing({
  total,
  remaining,
  done,
  accentColor = '#0a7ea4',
}: {
  total: number;
  remaining: number;
  done: boolean;
  accentColor?: string;
}) {
  const SIZE = 168;
  const HALF = SIZE / 2;
  const RING = 14;
  const INNER = SIZE - RING * 2;

  const progress = total > 0 ? remaining / total : 0;
  const angle = progress * 360;

  const arcColor = done
    ? '#2a7a4a'
    : remaining <= 5
    ? '#c0392b'
    : remaining <= Math.max(total * 0.2, 10)
    ? '#e67e22'
    : accentColor;

  const pulseAnim = useRef(new Animated.Value(1)).current;
  useEffect(() => {
    if (remaining > 0 && remaining <= 5 && !done) {
      const loop = Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, { toValue: 1.07, duration: 350, useNativeDriver: true }),
          Animated.timing(pulseAnim, { toValue: 1.0,  duration: 350, useNativeDriver: true }),
        ]),
      );
      loop.start();
      return () => loop.stop();
    } else {
      pulseAnim.setValue(1.0);
    }
  }, [remaining, done]);

  const rightDeg = Math.min(angle, 180) - 180;
  const leftDeg  = Math.max(angle - 180, 0) - 180;

  return (
    <Animated.View style={[styles.ringWrapper, { transform: [{ scale: pulseAnim }] }]}>
      <View style={{ position: 'absolute', width: SIZE, height: SIZE, borderRadius: HALF, backgroundColor: '#2a2a2a' }} />

      <View style={{ position: 'absolute', top: 0, right: 0, width: HALF, height: SIZE, overflow: 'hidden' }}>
        <View style={{
          position: 'absolute', top: 0, left: -HALF,
          width: SIZE, height: SIZE, borderRadius: HALF,
          backgroundColor: arcColor,
          transform: [{ rotate: `${rightDeg}deg` }],
        }} />
      </View>

      <View style={{ position: 'absolute', top: 0, left: 0, width: HALF, height: SIZE, overflow: 'hidden' }}>
        <View style={{
          position: 'absolute', top: 0, left: 0,
          width: SIZE, height: SIZE, borderRadius: HALF,
          backgroundColor: arcColor,
          transform: [{ rotate: `${leftDeg}deg` }],
        }} />
      </View>

      <View style={{
        position: 'absolute', top: RING, left: RING,
        width: INNER, height: INNER, borderRadius: INNER / 2,
        backgroundColor: '#121212',
        alignItems: 'center', justifyContent: 'center',
      }}>
        <Text style={[styles.ringTime, { color: arcColor }]}>{formatTime(remaining)}</Text>
        <Text style={styles.ringSub}>{done ? t('workout.ringDone') : t('workout.ringRemaining')}</Text>
      </View>
    </Animated.View>
  );
}

// ─────────────────────────────────────────
// Hauptscreen
// ─────────────────────────────────────────

export default function ActiveWorkoutScreen() {
  const { planId, planName, dayId } = useLocalSearchParams<{ planId?: string; planName?: string; dayId?: string }>();
  const hasPlan = !!planId;
  const { t } = useTranslation();

  // ── Plan-Daten ──
  const [planExercises, setPlanExercises] = useState<PlanExercise[]>([]);
  const [planMeta, setPlanMeta]           = useState<PlanMeta | null>(null);
  const [dayInfo, setDayInfo]             = useState<PlanDayInfo | null>(null);
  const [planIndex, setPlanIndex]         = useState(0);
  const [countdownFrom, setCountdownFrom] = useState(0);
  const [detailVisible, setDetailVisible] = useState(false);

  // ── Zirkel-Zustand ──
  const [currentRound, setCurrentRound] = useState(1);

  // ── Pause-Phase (zwischen Übungen oder Runden) ──
  // null = kein Rest; 'exercise' = Pause zwischen Übungen; 'round' = Pause zwischen Runden
  type RestPhase = 'exercise' | 'round' | null;
  const [restPhase, setRestPhase]         = useState<RestPhase>(null);
  const [restTotal, setRestTotal]         = useState(0);
  const [restRemaining, setRestRemaining] = useState(0);
  const restIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // ── Gesamt-Timer ──
  const [elapsed, setElapsed]           = useState(0);
  const [totalElapsed, setTotalElapsed] = useState(0);
  const [countdownDone, setCountdownDone] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // ── Kalorienverbrauch (MET-basiert, siehe lib/calorieBurn.ts) ──
  // weightKg + intensityFactor kommen aus dem Profil; burnMarkRef merkt sich den
  // totalElapsed-Stand beim letzten gespeicherten Satz, sodass jeder Satz-Log
  // nur seinen Zeitanteil als calories_burned bekommt (Summe = Session-Verbrauch).
  const [weightKg, setWeightKg]             = useState<number | null>(null);
  const [intensityFactor, setIntensityFactor] = useState(1);
  const [sessionKcal, setSessionKcal]       = useState(0);
  const burnMarkRef = useRef(0);

  // ── Eingabe ──
  const [exercise, setExercise] = useState('');
  const [weight, setWeight]     = useState('');
  const [reps, setReps]         = useState('');
  const [saving, setSaving]     = useState(false);
  const [inputError, setInputError] = useState('');

  // ── Protokoll ──
  const [sets, setSets] = useState<LoggedSet[]>([]);
  const [setsThisExercise, setSetsThisExercise] = useState(0);
  const [isFinished, setIsFinished] = useState(false);

  // ── Plan laden ──
  useEffect(() => {
    if (!hasPlan) return;
    async function loadPlan() {
      // Plan-Meta laden
      const { data: meta } = await supabase
        .from('workout_plans')
        .select('is_circuit, circuit_rounds, rest_between_exercises_seconds, rest_between_rounds_seconds')
        .eq('id', planId)
        .single();
      if (meta) setPlanMeta(meta as PlanMeta);

      // Split-Tage laden (falls vorhanden — alte/manuelle Pläne haben keine)
      const { data: days } = await supabase
        .from('plan_days')
        .select('id, day_index, label, warmup, cooldown')
        .eq('plan_id', planId)
        .order('day_index');

      let resolvedDayId: string | null = null;
      if (days && days.length > 0) {
        const chosen = (dayId ? days.find((d) => d.id === dayId) : undefined) ?? days[0];
        resolvedDayId = chosen.id;
        setDayInfo({ id: chosen.id, label: chosen.label, warmup: chosen.warmup, cooldown: chosen.cooldown });
      } else {
        setDayInfo(null);
      }

      // Übungen laden — bei Split-Plänen nur die des gewählten Tages
      let query = supabase
        .from('plan_exercises')
        .select('id, exercise_name, description, muscle_group, equipment_type, sets, reps, target_duration, target_weight_kg, rest_seconds, name_en, short, detail_markdown, instructions, modifications, safety, tips')
        .eq('plan_id', planId)
        .order('order_index');
      if (resolvedDayId) query = query.eq('day_id', resolvedDayId);

      const { data, error } = await query;
      if (error) { console.error('Plan-Übungen laden:', error.message); return; }
      if (!data || data.length === 0) return;
      setPlanExercises(data);
      setExercise(data[0].exercise_name);
      setCountdownFrom(data[0].target_duration ?? 0);
      setReps(data[0].reps ? String(data[0].reps) : '');
      const lastWeight = await loadLastWeight(data[0].exercise_name);
      setWeight(lastWeight || (data[0].target_weight_kg != null ? formatDecimal(data[0].target_weight_kg) : ''));
    }
    loadPlan();
  }, [planId, dayId]);

  // ── Gesamt-Timer (läuft immer, auch in Pausen) ──
  useEffect(() => {
    intervalRef.current = setInterval(() => {
      setElapsed((e) => e + 1);
      setTotalElapsed((t) => t + 1);
    }, 1000);
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, []);

  // ── Profil-Daten für die Kalorienschätzung laden ──
  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      const { data } = await supabase
        .from('profiles')
        .select('weight_kg, workout_intensity_factor')
        .eq('id', user.id)
        .single();
      if (data) {
        setWeightKg(data.weight_kg ?? null);
        setIntensityFactor(data.workout_intensity_factor ?? 1);
      }
    })();
  }, []);

  // ── Übungs-Countdown Ende ──
  useEffect(() => {
    if (countdownFrom > 0 && elapsed >= countdownFrom && !countdownDone) {
      setCountdownDone(true);
      playBeep();
    }
  }, [elapsed, countdownFrom, countdownDone]);

  // ── Pause-Countdown ──
  useEffect(() => {
    if (restPhase === null) return;
    if (restIntervalRef.current) clearInterval(restIntervalRef.current);
    restIntervalRef.current = setInterval(() => {
      setRestRemaining((r) => {
        if (r <= 1) {
          clearInterval(restIntervalRef.current!);
          // Wird nach State-Update in separatem Effect behandelt
          return 0;
        }
        return r - 1;
      });
    }, 1000);
    return () => { if (restIntervalRef.current) clearInterval(restIntervalRef.current); };
  }, [restPhase]);

  // ── Wenn Pause abgelaufen → nächste Übung SOFORT starten ──
  useEffect(() => {
    if (restPhase !== null && restRemaining === 0 && planExercises.length > 0) {
      playBeep();
      const targetIdx = restPhase === 'round' ? 0 : planIndex;
      setRestPhase(null);
      goToExercise(targetIdx);
    }
  }, [restRemaining, restPhase]);

  function resetSetTimer() {
    setElapsed(0);
    setCountdownDone(false);
  }

  async function loadLastWeight(exerciseName: string): Promise<string> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return '';
    const { data } = await supabase
      .from('exercise_logs')
      .select('weight_kg')
      .eq('user_id', user.id)
      .eq('exercise_name', exerciseName)
      .not('weight_kg', 'is', null)
      .order('created_at', { ascending: false })
      .limit(1);
    return data?.[0]?.weight_kg ? formatDecimal(data[0].weight_kg) : '';
  }

  async function goToExercise(idx: number) {
    const next = planExercises[idx];
    if (!next) return;
    setPlanIndex(idx);
    setExercise(next.exercise_name);
    setCountdownFrom(next.target_duration ?? 0);
    setSetsThisExercise(0);
    setReps(next.reps ? String(next.reps) : '');
    resetSetTimer();
    const lastWeight = await loadLastWeight(next.exercise_name);
    setWeight(lastWeight || (next.target_weight_kg != null ? formatDecimal(next.target_weight_kg) : ''));
  }

  function startRestBetweenExercises(nextExerciseIdx: number) {
    const sec = planMeta?.rest_between_exercises_seconds ?? 15;
    setPlanIndex(nextExerciseIdx); // merken, wohin wir nach der Pause gehen
    setRestPhase('exercise');
    setRestTotal(sec);
    setRestRemaining(sec);
  }

  function startRestBetweenRounds(nextRound: number) {
    const sec = planMeta?.rest_between_rounds_seconds ?? 60;
    setCurrentRound(nextRound);
    setRestPhase('round');
    setRestTotal(sec);
    setRestRemaining(sec);
  }

  async function handleSaveSet() {
    setInputError('');
    if (!exercise.trim()) { setInputError(t('workout.nameRequired')); return; }
    const isDurationEx = countdownFrom > 0;
    if (!isDurationEx && !reps.trim()) { setInputError(t('workout.repsRequired')); return; }

    setSaving(true);
    const { data: { user } } = await supabase.auth.getUser();

    // Kalorien für den Zeitabschnitt seit dem letzten Satz schätzen.
    const segmentSeconds = Math.max(0, totalElapsed - burnMarkRef.current);
    const segmentKcal = estimateWorkoutKcal(
      segmentSeconds,
      weightKg,
      planMeta?.is_circuit ? 'circuit' : 'strength',
      intensityFactor,
    );

    const { error } = await supabase.from('exercise_logs').insert({
      user_id: user?.id,
      exercise_name: exercise.trim(),
      weight_kg: weight && !isNaN(parseDecimal(weight)) ? parseDecimal(weight) : null,
      reps: reps ? parseInt(reps, 10) : null,
      duration_seconds: isDurationEx ? countdownFrom : elapsed,
      workout_total_seconds: totalElapsed,
      calories_burned: segmentKcal,
    });

    setSaving(false);
    if (error) { setInputError(t('workout.saveFailed', { message: error.message })); return; }

    burnMarkRef.current = totalElapsed;
    setSessionKcal((k) => k + segmentKcal);

    const newSetsThisEx = setsThisExercise + 1;
    setSetsThisExercise(newSetsThisEx);

    setSets((prev) => [
      {
        id: Date.now().toString(),
        exercise: exercise.trim(),
        weight,
        reps: reps || (isDurationEx ? `${countdownFrom}s` : '—'),
        duration: elapsed,
      },
      ...prev,
    ]);

    resetSetTimer();
    setReps('');

    const isCircuit = planMeta?.is_circuit ?? false;

    if (isCircuit && hasPlan) {
      // ── Zirkel-Logik ──
      const nextExIdx = planIndex + 1;
      const totalRounds = planMeta?.circuit_rounds ?? 3;

      if (nextExIdx < planExercises.length) {
        // Noch Übungen in dieser Runde → Pause zwischen Übungen
        startRestBetweenExercises(nextExIdx);
      } else {
        // Letzte Übung der Runde
        const nextRound = currentRound + 1;
        if (nextRound <= totalRounds) {
          // Weitere Runden → Pause zwischen Runden, dann Runde neu starten
          startRestBetweenRounds(nextRound);
        }
        // Wenn alle Runden durch → Workout beendet
        if (nextRound > totalRounds) {
          setIsFinished(true);
          if (intervalRef.current) clearInterval(intervalRef.current);
        }
      }
    } else if (hasPlan && planExercises.length > 0) {
      // ── Standard-Logik: Auto-Weiter nach Soll-Sätzen ──
      const currentPlanEx = planExercises[planIndex];
      const targetSets = currentPlanEx?.sets ?? 1;
      const nextIdx = planIndex + 1;
      if (newSetsThisEx >= targetSets && nextIdx < planExercises.length) {
        setTimeout(() => goToExercise(nextIdx), 800);
      }
    }
  }

  function handleNextExercise() {
    const next = planIndex + 1;
    if (next >= planExercises.length) return;
    goToExercise(next);
  }

  function skipRest() {
    setRestRemaining(0);
  }

  // ── Abgeleitete Werte ──
  const isCountdownMode = countdownFrom > 0;
  const remaining       = Math.max(0, countdownFrom - elapsed);
  const currentPlanEx   = planExercises[planIndex];
  const isCircuit       = planMeta?.is_circuit ?? false;
  const totalRounds     = planMeta?.circuit_rounds ?? 3;
  const allCircuitDone  = isCircuit && currentRound > totalRounds && restPhase === null;

  return (
    <KeyboardAvoidingView
      style={styles.flex}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView
        contentContainerStyle={styles.container}
        keyboardShouldPersistTaps="handled"
      >
        {/* ── Plan-Banner ── */}
        {hasPlan && planExercises.length > 0 && (
          <View style={[styles.planBanner, isCircuit && styles.planBannerCircuit]}>
            <View style={styles.planBannerLeft}>
              <Text style={styles.planBannerTitle}>
                {planName}{dayInfo ? ` · ${dayInfo.label}` : ''}
              </Text>
              {restPhase ? (
                <Text style={styles.planBannerSub}>
                  {restPhase === 'round'
                    ? t('workout.roundRest', { round: currentRound, total: totalRounds })
                    : t('workout.restNext', { name: planExercises[planIndex]?.exercise_name ?? '' })}
                </Text>
              ) : isCircuit ? (
                <Text style={styles.planBannerSub}>
                  {allCircuitDone
                    ? t('workout.circuitDone')
                    : t('workout.roundProgress', { round: currentRound, total: totalRounds, n: planIndex + 1, count: planExercises.length })}
                </Text>
              ) : (
                <Text style={styles.planBannerSub}>
                  {t('workout.exerciseProgress', { n: planIndex + 1, count: planExercises.length })}
                  {currentPlanEx
                    ? t('workout.setProgress', { n: setsThisExercise + 1, total: currentPlanEx.sets }) +
                      (currentPlanEx.target_duration
                        ? ` · ${currentPlanEx.target_duration}s`
                        : currentPlanEx.reps
                        ? t('workout.repsSuffix', { reps: currentPlanEx.reps })
                        : '')
                    : ''}
                </Text>
              )}
            </View>
            {!isCircuit && planIndex + 1 < planExercises.length && restPhase === null && (
              <TouchableOpacity style={styles.nextExBtn} onPress={handleNextExercise}>
                <Text style={styles.nextExText}>{t('workout.next')}</Text>
              </TouchableOpacity>
            )}
            {restPhase && (
              <TouchableOpacity style={styles.skipRestBtn} onPress={skipRest}>
                <Text style={styles.skipRestText}>{t('workout.skip')}</Text>
              </TouchableOpacity>
            )}
          </View>
        )}

        {/* ── Warm-up (nur vor dem ersten Satz) ── */}
        {dayInfo?.warmup && planIndex === 0 && sets.length === 0 && !restPhase && !isFinished && (
          <View style={styles.noteCard}>
            <Text style={styles.noteCardLabel}>{t('workout.warmup')}</Text>
            <Text style={styles.noteCardText}>{dayInfo.warmup}</Text>
          </View>
        )}

        {/* ── Gesamt-Timer ── */}
        <View style={styles.totalTimerRow}>
          <Text style={styles.totalTimerLabel}>{t('workout.totalTime')}</Text>
          <Text style={styles.totalTimerValue}>
            {formatTime(totalElapsed)}
            {sessionKcal > 0 ? ` · ~${sessionKcal} kcal` : ''}
          </Text>
        </View>

        {/* ── Pause-Countdown (überlagert den normalen Timer) ── */}
        {restPhase ? (
          <View style={styles.ringContainer}>
            <CountdownRing
              total={restTotal}
              remaining={restRemaining}
              done={restRemaining === 0}
              accentColor={restPhase === 'round' ? '#ff9800' : '#4caf50'}
            />
            <Text style={styles.restLabel}>
              {restPhase === 'round' ? t('workout.restBetweenRounds') : t('workout.restBetweenExercises')}
            </Text>
          </View>
        ) : isCountdownMode ? (
          /* Übungs-Countdown-Kreis */
          <View style={styles.ringContainer}>
            <CountdownRing
              total={countdownFrom}
              remaining={remaining}
              done={countdownDone}
            />
            {countdownDone && (
              <Text style={styles.countdownDoneHint}>{t('workout.timeUp')}</Text>
            )}
          </View>
        ) : (
          /* Normaler Satz-Timer */
          <View style={styles.setTimerCard}>
            <Text style={styles.setTimerLabel}>{t('workout.setTimer')}</Text>
            <Text style={styles.setTimerValue}>{formatTime(elapsed)}</Text>
            <Text style={styles.setTimerSub}>
              {sets.length === 0 ? t('workout.firstSetRunning') : t('workout.restAfterSet', { n: sets.length })}
            </Text>
          </View>
        )}

        {/* ── Eingabemaske (während Pause oder nach Abschluss ausgeblendet) ── */}
        {!restPhase && !allCircuitDone && !isFinished && (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>
              {isCircuit ? t('workout.roundExercise', { round: currentRound, n: planIndex + 1 }) : t('workout.setN', { n: sets.length + 1 })}
            </Text>

            {currentPlanEx && (currentPlanEx.description || currentPlanEx.muscle_group || currentPlanEx.equipment_type) && (
              <View style={styles.exerciseIdentity}>
                {!!(currentPlanEx.muscle_group || currentPlanEx.equipment_type) && (
                  <View style={styles.exercisePictoBox}>
                    <Text style={styles.exercisePictoText} numberOfLines={2}>
                      {[currentPlanEx.muscle_group, currentPlanEx.equipment_type].filter(Boolean).join(' / ')}
                    </Text>
                  </View>
                )}
                {!!currentPlanEx.description && (
                  <Text style={styles.exerciseDescription} numberOfLines={2}>{currentPlanEx.description}</Text>
                )}
                {!!currentPlanEx.detail_markdown && (
                  <TouchableOpacity
                    style={styles.infoButton}
                    onPress={() => setDetailVisible(true)}
                    hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                  >
                    <Text style={styles.infoButtonText}>ⓘ</Text>
                  </TouchableOpacity>
                )}
              </View>
            )}

            <Text style={styles.label}>{t('workout.exerciseName')}</Text>
            <TextInput
              style={styles.input}
              value={exercise}
              onChangeText={setExercise}
              placeholder={t('workout.exercisePlaceholder')}
              placeholderTextColor="#555"
              returnKeyType="next"
            />

            <View style={styles.row}>
              <View style={styles.halfField}>
                <Text style={styles.label}>{t('workout.weight')}</Text>
                <TextInput
                  style={styles.input}
                  value={weight}
                  onChangeText={(v) => setWeight(sanitizeDecimalInput(v))}
                  placeholder="0"
                  placeholderTextColor="#555"
                  keyboardType="decimal-pad"
                  returnKeyType="next"
                />
              </View>
              <View style={styles.halfField}>
                <Text style={styles.label}>{isCountdownMode ? t('workout.repsOptional') : t('workout.reps')}</Text>
                <TextInput
                  style={styles.input}
                  value={reps}
                  onChangeText={setReps}
                  placeholder={isCountdownMode ? '—' : '0'}
                  placeholderTextColor="#555"
                  keyboardType="number-pad"
                  returnKeyType="done"
                  onSubmitEditing={handleSaveSet}
                />
              </View>
            </View>

            {inputError ? <Text style={styles.inputError}>{inputError}</Text> : null}

            <TouchableOpacity
              style={[
                styles.saveButton,
                saving && styles.saveButtonDisabled,
                isCountdownMode && countdownDone && styles.saveButtonReady,
              ]}
              onPress={handleSaveSet}
              disabled={saving}
              activeOpacity={0.8}
            >
              <Text style={styles.saveButtonText}>
                {saving ? t('workout.saving') : t('workout.finishSet')}
              </Text>
            </TouchableOpacity>
          </View>
        )}

        {/* ── Zirkel abgeschlossen (mid-session banner) ── */}
        {allCircuitDone && !isFinished && (
          <View style={styles.circuitDoneCard}>
            <Text style={styles.circuitDoneEmoji}>🎉</Text>
            <Text style={styles.circuitDoneTitle}>{t('workout.circuitDoneTitle')}</Text>
            <Text style={styles.circuitDoneSub}>
              {t('workout.circuitDoneSub', { count: totalRounds, exercises: planExercises.length })}
            </Text>
          </View>
        )}

        {/* ── Summary ── */}
        {isFinished && (
          <View style={styles.summaryCard}>
            <Text style={styles.summaryTitle}>{t('workout.finished')}</Text>
            <View style={styles.summaryStats}>
              <View style={styles.summaryStat}>
                <Text style={styles.summaryStatValue}>{formatTime(totalElapsed)}</Text>
                <Text style={styles.summaryStatLabel}>{t('workout.duration')}</Text>
              </View>
              <View style={styles.summaryDivider} />
              <View style={styles.summaryStat}>
                <Text style={styles.summaryStatValue}>{sessionKcal}</Text>
                <Text style={styles.summaryStatLabel}>{t('workout.kcalBurned')}</Text>
              </View>
              <View style={styles.summaryDivider} />
              <View style={styles.summaryStat}>
                <Text style={styles.summaryStatValue}>{sets.length}</Text>
                <Text style={styles.summaryStatLabel}>{t('workout.totalSets')}</Text>
              </View>
            </View>
          </View>
        )}

        {/* ── Cool-down ── */}
        {isFinished && dayInfo?.cooldown && (
          <View style={styles.noteCard}>
            <Text style={styles.noteCardLabel}>{t('workout.cooldown')}</Text>
            <Text style={styles.noteCardText}>{dayInfo.cooldown}</Text>
          </View>
        )}

        {/* ── Protokoll ── */}
        {sets.length > 0 && (
          <View style={styles.logSection}>
            <Text style={styles.logTitle}>{t('workout.log')}</Text>
            {sets.map((set, index) => (
              <View key={set.id} style={styles.logRow}>
                <View style={styles.logLeft}>
                  <Text style={styles.logIndex}>#{sets.length - index}</Text>
                  <View>
                    <Text style={styles.logExercise}>{set.exercise}</Text>
                    <Text style={styles.logDetail}>
                      {set.weight ? `${set.weight} kg · ` : ''}{set.reps}
                    </Text>
                  </View>
                </View>
                <Text style={styles.logTime}>{formatTime(set.duration)}</Text>
              </View>
            ))}
          </View>
        )}

        <TouchableOpacity
          style={[styles.finishButton, allCircuitDone && styles.finishButtonDone]}
          onPress={() => router.back()}
          activeOpacity={0.8}
        >
          <Text style={[styles.finishButtonText, allCircuitDone && styles.finishButtonTextDone]}>
            {allCircuitDone ? t('workout.completeTraining') : t('workout.endTraining')}
          </Text>
        </TouchableOpacity>
      </ScrollView>

      <ExerciseDetailModal
        visible={detailVisible}
        exercise={currentPlanEx ?? null}
        onClose={() => setDetailVisible(false)}
      />
    </KeyboardAvoidingView>
  );
}

// ─────────────────────────────────────────
// Styles
// ─────────────────────────────────────────

const styles = StyleSheet.create({
  flex:      { flex: 1, backgroundColor: '#121212' },
  container: { flexGrow: 1, padding: 20, paddingTop: 24, paddingBottom: 48 },

  totalTimerRow: {
    flexDirection: 'row', justifyContent: 'space-between',
    alignItems: 'center', marginBottom: 20,
  },
  totalTimerLabel: { color: '#666', fontSize: 13 },
  totalTimerValue: { color: '#666', fontSize: 14 },

  ringWrapper: { width: 168, height: 168 },
  ringContainer: { alignItems: 'center', marginBottom: 24, gap: 12 },
  ringTime: { fontSize: 36, fontWeight: '800', lineHeight: 42 },
  ringSub: {
    color: '#888', fontSize: 11, fontWeight: '600',
    textTransform: 'uppercase', letterSpacing: 0.6, marginTop: 2,
  },
  countdownDoneHint: { color: '#2a7a4a', fontSize: 13, fontWeight: '600', textAlign: 'center' },
  restLabel:         { color: '#888', fontSize: 13, fontWeight: '600', textAlign: 'center' },

  setTimerCard: {
    backgroundColor: '#0a7ea4', borderRadius: 20,
    paddingVertical: 28, alignItems: 'center', marginBottom: 20,
  },
  setTimerLabel: {
    color: 'rgba(255,255,255,0.7)', fontSize: 13, fontWeight: '600',
    textTransform: 'uppercase', letterSpacing: 1, marginBottom: 6,
  },
  setTimerValue: { color: '#fff', fontSize: 56, fontWeight: '800', lineHeight: 64 },
  setTimerSub:   { color: 'rgba(255,255,255,0.6)', fontSize: 13, marginTop: 4 },

  planBanner: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    backgroundColor: '#1a2a30', borderRadius: 14, padding: 14,
    marginBottom: 16, borderLeftWidth: 3, borderLeftColor: '#0a7ea4',
  },
  planBannerCircuit: { borderLeftColor: '#ff9800', backgroundColor: '#1e1a0a' },
  planBannerLeft:    { flex: 1 },
  planBannerTitle:   { color: '#0a7ea4', fontWeight: '700', fontSize: 14, marginBottom: 2 },
  planBannerSub:     { color: '#888', fontSize: 13 },
  nextExBtn: {
    backgroundColor: '#0a7ea4', borderRadius: 8,
    paddingHorizontal: 12, paddingVertical: 7, marginLeft: 10,
  },
  nextExText:  { color: '#fff', fontSize: 13, fontWeight: '700' },
  skipRestBtn: {
    backgroundColor: '#2a2a2a', borderRadius: 8,
    paddingHorizontal: 12, paddingVertical: 7, marginLeft: 10,
  },
  skipRestText: { color: '#aaa', fontSize: 12, fontWeight: '600' },

  noteCard: {
    backgroundColor: '#1e1e1e', borderRadius: 14,
    padding: 16, marginBottom: 16, borderWidth: 1, borderColor: '#2a2a2a',
  },
  noteCardLabel: { color: '#0a7ea4', fontSize: 13, fontWeight: '700', marginBottom: 6 },
  noteCardText:  { color: '#aaa', fontSize: 13, lineHeight: 19 },

  card: {
    backgroundColor: '#1e1e1e', borderRadius: 16,
    padding: 20, marginBottom: 20,
  },
  cardTitle: { color: '#fff', fontSize: 18, fontWeight: '700', marginBottom: 16 },
  exerciseIdentity:     { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 16 },
  exercisePictoBox:     { width: 76, minHeight: 40, borderRadius: 10, borderWidth: 1, borderColor: '#0a7ea4', backgroundColor: '#1a2a30', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 6, paddingVertical: 4 },
  exercisePictoText:    { color: '#0a7ea4', fontSize: 11, fontWeight: '700', textAlign: 'center', lineHeight: 14 },
  exerciseDescription:  { color: '#aaa', fontSize: 13, flex: 1 },
  infoButton:           { paddingHorizontal: 6, paddingVertical: 2 },
  infoButtonText:       { color: '#0a7ea4', fontSize: 20, fontWeight: '700' },
  label: {
    fontSize: 12, fontWeight: '600', color: '#aaa',
    textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 6,
  },
  input: {
    backgroundColor: '#2a2a2a', borderRadius: 10,
    padding: 14, fontSize: 16, color: '#fff',
    borderWidth: 1, borderColor: '#333', marginBottom: 12,
  },
  row:       { flexDirection: 'row', gap: 12 },
  halfField: { flex: 1 },

  saveButton:         { marginTop: 8, backgroundColor: '#0a7ea4', borderRadius: 12, padding: 18, alignItems: 'center' },
  saveButtonDisabled: { opacity: 0.5 },
  saveButtonReady:    { backgroundColor: '#2a7a4a' },
  saveButtonText:     { color: '#fff', fontSize: 17, fontWeight: '700' },
  inputError:         { color: '#c0392b', fontSize: 13, fontWeight: '600', marginBottom: 8, textAlign: 'center' },

  circuitDoneCard: {
    backgroundColor: '#1a3a28', borderRadius: 16,
    padding: 28, alignItems: 'center', marginBottom: 20,
    borderWidth: 1, borderColor: '#2a7a4a',
  },
  circuitDoneEmoji: { fontSize: 40, marginBottom: 10 },
  circuitDoneTitle: { color: '#4caf50', fontSize: 20, fontWeight: '800', marginBottom: 4 },
  circuitDoneSub:   { color: '#888', fontSize: 14 },

  logSection: { marginBottom: 20 },
  logTitle: {
    color: '#999', fontSize: 12, fontWeight: '600',
    textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 10,
  },
  logRow: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    backgroundColor: '#1e1e1e', borderRadius: 10,
    paddingVertical: 12, paddingHorizontal: 14, marginBottom: 6,
  },
  logLeft:     { flexDirection: 'row', alignItems: 'center', gap: 12 },
  logIndex:    { color: '#0a7ea4', fontSize: 13, fontWeight: '700', width: 28 },
  logExercise: { color: '#fff', fontSize: 15, fontWeight: '600' },
  logDetail:   { color: '#666', fontSize: 13, marginTop: 2 },
  logTime:     { color: '#555', fontSize: 13 },

  finishButton: {
    borderWidth: 1, borderColor: '#333', borderRadius: 12,
    padding: 16, alignItems: 'center',
  },
  finishButtonDone: {
    backgroundColor: '#2a7a4a', borderColor: '#2a7a4a', padding: 20,
  },
  finishButtonText:     { color: '#666', fontSize: 15, fontWeight: '600' },
  finishButtonTextDone: { color: '#fff', fontSize: 17, fontWeight: '800' },

  summaryCard: {
    backgroundColor: '#1a3a28', borderRadius: 20,
    padding: 28, marginBottom: 20,
    borderWidth: 1, borderColor: '#2a7a4a', alignItems: 'center',
  },
  summaryTitle: { color: '#4caf50', fontSize: 22, fontWeight: '800', marginBottom: 24 },
  summaryStats: { flexDirection: 'row', alignItems: 'center', width: '100%', justifyContent: 'center' },
  summaryStat:  { flex: 1, alignItems: 'center' },
  summaryStatValue: { color: '#fff', fontSize: 24, fontWeight: '800', lineHeight: 28 },
  summaryStatLabel: { color: '#999', fontSize: 11, fontWeight: '600', textTransform: 'uppercase', letterSpacing: 0.6, marginTop: 4 },
  summaryDivider: { width: 1, height: 40, backgroundColor: '#2a2a2a', marginHorizontal: 8 },
});
